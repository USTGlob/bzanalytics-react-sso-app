import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Callback = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const fetchToken = async () => {
      const params = new URLSearchParams(window.location.search);
      const code = params.get('code');

      if (!code) {
        navigate('/login');
        return;
      }

      try {
        const response = await axios.post('https://oauth2.googleapis.com/token', null, {
          params: {
            code: code,
            client_id: '600028731911-hruliarpgf983n89djf8jm4fr23dt0tp.apps.googleusercontent.com', // Replace with your Client ID
            client_secret: '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', // Replace with your Client Secret
            redirect_uri: 'https://www.bzanalytics.ai/callback', // Update redirect URI
            grant_type: 'authorization_code'
          }
        });

        const accessToken = response.data.access_token;
        localStorage.setItem('accessToken', accessToken);
        navigate('/dashboard');
      } catch (error) {
        console.error('Error exchanging code for token', error);
        navigate('/login');
      }
    };
    fetchToken();
  }, [navigate]);

  return (
    <div>
      <h2>Logging in...</h2>
    </div>
  );
};

export default Callback;
