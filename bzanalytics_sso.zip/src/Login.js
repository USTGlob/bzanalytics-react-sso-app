import React from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = () => {
    const clientId = '600028731911-hruliarpgf983n89djf8jm4fr23dt0tp.apps.googleusercontent.com'; // Replace with your Client ID
    const redirectUri = 'https://www.bzanalytics.ai/callback'; // Update redirect URI
    const scope = 'openid email profile';
    const responseType = 'code';

    const url = `https://accounts.google.com/o/oauth2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=${responseType}&scope=${scope}`;

    window.location.href = url;
  };

  return (
    <div>
      <h2>Login Page</h2>
      <button onClick={handleLogin}>Login with Google</button>
    </div>
  );
};

export default Login;
